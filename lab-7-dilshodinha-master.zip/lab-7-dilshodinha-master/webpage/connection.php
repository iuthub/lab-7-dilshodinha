<?php
    
	$user = "root";
	$password1 = "";
    $blogg=new PDO("mysql:dbname=blog;host=localhost;", $user, $password1);

 ?>
